// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB81SLqMtU-3mWa1cw2BHYMZfKNWLDaT8c",
  authDomain: "aula-um-thiago.firebaseapp.com",
  projectId: "aula-um-thiago",
  storageBucket: "aula-um-thiago.appspot.com",
  messagingSenderId: "813899286762",
  appId: "1:813899286762:web:5f1a4bb8c8eb0876d96f93",
  measurementId: "G-7297PRBBHH"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

export default app;