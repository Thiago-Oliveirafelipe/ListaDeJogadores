import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import realizarLogin from './screens/realizarLogin';
import paginaPrincipal from './screens/paginaPrincipal';
import ListarJogador from './screens/ListarJogador'; 

const Stack = createNativeStackNavigator();

const App = () => (
  <NavigationContainer>
    <Stack.Navigator initialRouteName="RealizarLogin">
      <Stack.Screen name="realizarLogin" component={realizarLogin} />
      <Stack.Screen name="paginaPrincipal" component={paginaPrincipal} />
      <Stack.Screen name="ListarJogador" component={ListarJogador} />
    </Stack.Navigator>
  </NavigationContainer>
);

export default App;